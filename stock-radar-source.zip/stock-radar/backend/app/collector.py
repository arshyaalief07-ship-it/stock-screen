import time
import logging
from datetime import datetime, timezone
import yfinance as yf
from .db import supabase
from .indicators import analyze

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("collector")

def run():
    stocks = supabase.table("stocks").select("symbol").eq("is_active", True).execute().data or []
    log.info("Universe aktif: %s ticker", len(stocks))
    for idx, item in enumerate(stocks, 1):
        symbol = item["symbol"]
        try:
            hist = yf.Ticker(symbol).history(period="2y", interval="1d", auto_adjust=False)
            if hist.empty:
                log.warning("%s: data kosong", symbol)
                continue
            signal = analyze(hist)
            if signal is None:
                log.warning("%s: histori kurang dari 200 candle", symbol)
                continue

            rows = []
            for dt, row in hist.tail(500).iterrows():
                if row.get("Close") is None:
                    continue
                rows.append({
                    "symbol": symbol, "trade_date": dt.date().isoformat(),
                    "open": float(row["Open"]) if row["Open"] == row["Open"] else None,
                    "high": float(row["High"]) if row["High"] == row["High"] else None,
                    "low": float(row["Low"]) if row["Low"] == row["Low"] else None,
                    "close": float(row["Close"]),
                    "adj_close": float(row["Adj Close"]) if "Adj Close" in row and row["Adj Close"] == row["Adj Close"] else None,
                    "volume": int(row["Volume"]) if row["Volume"] == row["Volume"] else 0,
                    "source": "Yahoo Finance"
                })
            if rows:
                supabase.table("daily_prices").upsert(rows, on_conflict="symbol,trade_date").execute()

            latest_date = hist.index[-1].date().isoformat()
            payload = {"symbol": symbol, "trade_date": latest_date, **signal,
                       "updated_at": datetime.now(timezone.utc).isoformat()}
            supabase.table("daily_signals").upsert(payload, on_conflict="symbol").execute()
            log.info("[%s/%s] %s score=%s", idx, len(stocks), symbol, signal["score"])
        except Exception:
            log.exception("%s gagal diproses", symbol)
        time.sleep(1.2)  # throttle sederhana untuk mengurangi risiko rate limit

if __name__ == "__main__":
    run()
