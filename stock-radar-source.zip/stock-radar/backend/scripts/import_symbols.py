import csv, sys
from pathlib import Path
from app.db import supabase

if len(sys.argv) < 2:
    raise SystemExit("Usage: python scripts/import_symbols.py daftar_emiten.csv")
path = Path(sys.argv[1])
if not path.exists():
    raise SystemExit(f"File tidak ditemukan: {path}")

with path.open(encoding="utf-8-sig", newline="") as f:
    sample = f.read(4096)
    f.seek(0)
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t")
    except csv.Error:
        dialect = csv.excel
    reader = csv.DictReader(f, dialect=dialect)
    fields = reader.fieldnames or []
    symbol_col = next((c for c in fields if c.lower().strip() in ("kode saham","symbol","ticker","kode")), None)
    name_col = next((c for c in fields if c.lower().strip() in ("nama perusahaan","nama emiten","name","company")), None)
    if not symbol_col:
        raise SystemExit(f"Kolom kode saham tidak ditemukan. Kolom tersedia: {fields}")
    rows, seen = [], set()
    for row in reader:
        raw = (row.get(symbol_col) or "").strip().upper()
        if not raw or raw in seen:
            continue
        seen.add(raw)
        symbol = raw if raw.endswith(".JK") else f"{raw}.JK"
        rows.append({"symbol": symbol, "name": (row.get(name_col) or "").strip() if name_col else None, "is_active": True})
for i in range(0, len(rows), 500):
    supabase.table("stocks").upsert(rows[i:i+500], on_conflict="symbol").execute()
print(f"Berhasil upsert {len(rows)} simbol. Verifikasi instrumen non-saham secara manual.")
