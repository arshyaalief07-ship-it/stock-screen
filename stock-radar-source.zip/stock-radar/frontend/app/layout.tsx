import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "STOCK RADAR | IDX Screener",
  description: "Daily technical stock screener for Indonesian equities"
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="id"><body>{children}</body></html>;
}
